// ============================================================================
// OLMS | FRONTEND CONTROLLERS | REST API INTEGRATION
// All persistent operations use OLMSApi (Express REST API). The browser keeps
// only the current session display state and the customer's temporary cart.
// ============================================================================

function byId(id) { return document.getElementById(id); }

function showMessage(elementId, type, message) {
    const box = byId(elementId);
    box.className = `message-box msg-${type}`;
    box.textContent = String(message ?? "");
}

function showError(elementId, error) {
    const box = byId(elementId);
    box.className = "message-box msg-error";
    box.textContent = error?.message || "An unexpected error occurred. Please try again.";
}

function clearMessage(elementId) {
    const box = byId(elementId);
    box.className = "message-box";
    box.textContent = "";
}

function formatMoney(value) { return `$${Number(value).toFixed(2)}`; }
function formatDate(value) {
    const date = new Date(value);
    return Number.isNaN(date.getTime()) ? "—" : date.toLocaleString([], { dateStyle: "medium", timeStyle: "short" });
}
function describeItems(order) {
    return (order.items || []).map(item => `${item.name} × ${item.quantity}`).join(", ");
}
function makeButton(label, className, onClick, hint = "") {
    const button = document.createElement("button");
    button.type = "button";
    button.textContent = label;
    button.className = className;
    if (hint) button.title = hint;
    button.addEventListener("click", onClick);
    return button;
}
function makeStatusBadge(status) {
    const badge = document.createElement("span");
    badge.className = `badge badge-${String(status).toLowerCase()}`;
    badge.textContent = status;
    return badge;
}
function renderTable(container, headers, rows, emptyText) {
    const table = document.createElement("table");
    const head = table.createTHead().insertRow();
    headers.forEach(label => {
        const th = document.createElement("th");
        th.textContent = label;
        head.appendChild(th);
    });
    const body = table.createTBody();
    if (!rows.length) {
        const cell = body.insertRow().insertCell();
        cell.colSpan = headers.length;
        cell.className = "empty-cell";
        cell.textContent = emptyText;
    }
    rows.forEach(values => {
        const row = body.insertRow();
        values.forEach(value => {
            const cell = row.insertCell();
            (Array.isArray(value) ? value : [value]).forEach(part => {
                cell.append(part instanceof Node ? part : String(part ?? ""));
            });
        });
    });
    const wrapper = document.createElement("div");
    wrapper.className = "table-scroll";
    wrapper.appendChild(table);
    container.replaceChildren(wrapper);
}
function showView(viewId) {
    ["authView", "customerView", "staffView"].forEach(id => byId(id).classList.toggle("hidden", id !== viewId));
}

// ----- Order status guide --------------------------------------------------
function nextStepsText(status) {
    const next = ORDER_STATUS_FLOW[status] || [];
    return next.length ? next.join(" or ") : "None (final status)";
}
function statusesThatCanBeCancelled() {
    return Object.keys(ORDER_STATUS_FLOW).filter(status => ORDER_STATUS_FLOW[status].includes(OrderStatus.CANCELLED));
}
function makeNoteLine(text, className = "") {
    const line = document.createElement("div");
    line.className = className;
    line.textContent = text;
    return line;
}
function buildStatusCell(status) {
    const info = ORDER_STATUS_INFO[status] || { meaning: "Status information unavailable.", cancelNote: "" };
    const note = document.createElement("div");
    note.className = "status-note";
    note.append(makeNoteLine(info.meaning));
    note.append(makeNoteLine(`Next: ${nextStepsText(status)}`));
    if (info.cancelNote) {
        const cancellable = (ORDER_STATUS_FLOW[status] || []).includes(OrderStatus.CANCELLED);
        note.append(makeNoteLine(info.cancelNote, cancellable ? "note-yes" : "note-no"));
    }
    return [makeStatusBadge(status), note];
}
function buildStatusFlow() {
    const flow = document.createElement("div");
    flow.className = "status-flow";
    [OrderStatus.PENDING, OrderStatus.PROCESSING, OrderStatus.SHIPPED, OrderStatus.DELIVERED].forEach((status, index) => {
        if (index) flow.append(makeNoteLine("→", "flow-arrow"));
        flow.append(makeStatusBadge(status));
    });
    const branch = document.createElement("div");
    branch.className = "status-branch";
    branch.append(makeStatusBadge(OrderStatus.CANCELLED));
    branch.append(`is only possible from ${statusesThatCanBeCancelled().join(" or ")}. A Shipped order cannot be cancelled.`);
    return [flow, branch];
}
function renderStatusGuide(containerId, introText) {
    const details = document.createElement("details");
    details.className = "status-guide";
    details.open = true;
    details.append(Object.assign(document.createElement("summary"), { textContent: "How order statuses work" }));
    details.append(makeNoteLine(introText, "field-hint intro-text"));
    details.append(...buildStatusFlow());
    const host = document.createElement("div");
    const rows = Object.values(OrderStatus).map(status => [
        makeStatusBadge(status), ORDER_STATUS_INFO[status].meaning,
        nextStepsText(status), ORDER_STATUS_INFO[status].cancelNote || "Already cancelled."
    ]);
    renderTable(host, ["Status", "What it means", "Next possible step", "Can it be cancelled?"], rows, "");
    details.append(host);
    byId(containerId).replaceChildren(details);
}

// ----- Application state ---------------------------------------------------
const app = { session: null, cart: [], products: [], orders: [] };
let catalogueQuery = "";
let lastStaffSearch = "";

function currentCustomer() { return app.session?.role === "customer" ? app.session.user : null; }
function currentStaff() { return app.session?.role === "staff" ? app.session.user : null; }
function requireSession(role) {
    if (!app.session || (role && app.session.role !== role)) throw new Error("Your session has expired. Please log in again.");
}

// ----- Authentication ------------------------------------------------------
async function handleLogin(event) {
    event.preventDefault();
    try {
        const role = byId("login_role").value;
        const user = await OLMSApi.login(role, byId("login_email").value, byId("login_password").value);
        app.session = { role, user };
        app.cart = [];
        byId("loginForm").reset();
        clearMessage("loginFeedback");
        await enterSession();
    } catch (error) { showError("loginFeedback", error); }
}
async function handleRegister(event) {
    event.preventDefault();
    try {
        const user = await OLMSApi.register({
            name: byId("register_name").value,
            email: byId("register_email").value,
            phone: byId("register_phone").value,
            password: byId("register_password").value
        });
        app.session = { role: "customer", user };
        app.cart = [];
        byId("registerForm").reset();
        clearMessage("registerFeedback");
        await enterSession();
    } catch (error) { showError("registerFeedback", error); }
}
async function handleLogout() {
    try { await OLMSApi.logout(); }
    catch (error) { console.warn("Logout request failed:", error.message); }
    app.session = null;
    app.cart = [];
    app.products = [];
    enterSession();
}
async function enterSession() {
    byId("sessionInfo").classList.toggle("hidden", !app.session);
    if (!app.session) { showView("authView"); return; }
    byId("sessionName").textContent = app.session.user.name;
    byId("sessionRole").textContent = app.session.role === "staff" ? `Staff · ${app.session.user.role}` : "Customer";
    if (app.session.role === "staff") {
        showView("staffView");
        await initStaffView();
    } else {
        showView("customerView");
        await initCustomerView();
    }
}

// ----- Customer catalogue and cart ----------------------------------------
async function initCustomerView() {
    catalogueQuery = "";
    byId("browse_query").value = "";
    clearMessage("browseFeedback");
    clearMessage("cartFeedback");
    byId("productDetailsDisplay").textContent = 'Select "Details" on a product to view it here.';
    renderStatusGuide("customerStatusGuide", "Your order moves through these steps. Store staff update the status; you can follow it in the table below.");
    await renderCatalogue();
    renderCart();
    await renderCustomerOrders();
}
async function handleBrowseProducts(event) {
    event.preventDefault();
    try {
        catalogueQuery = Validator.searchQuery(byId("browse_query").value);
        const count = await renderCatalogue();
        if (!catalogueQuery) clearMessage("browseFeedback");
        else if (!count) showMessage("browseFeedback", "error", `No product matching "${catalogueQuery}".`);
        else showMessage("browseFeedback", "info", `Found ${count} matching product(s).`);
    } catch (error) { showError("browseFeedback", error); }
}
async function handleShowAllProducts() {
    byId("browse_query").value = "";
    catalogueQuery = "";
    clearMessage("browseFeedback");
    await renderCatalogue();
}
async function renderCatalogue() {
    try {
        app.products = await OLMSApi.products.list(catalogueQuery);
        const rows = app.products.map(product => [
            product.name, formatMoney(product.price), product.stockQuantity > 0 ? product.stockQuantity : "Out of stock",
            buildCatalogueActions(product)
        ]);
        renderTable(byId("catalogueDisplay"), ["Product", "Price", "Stock", "Action"], rows, "No products available.");
        return app.products.length;
    } catch (error) { showError("browseFeedback", error); return 0; }
}
function buildCatalogueActions(product) {
    const outOfStock = product.stockQuantity === 0;
    const quantity = document.createElement("input");
    Object.assign(quantity, { type: "number", min: "1", max: String(product.stockQuantity), value: "1", className: "qty-input", disabled: outOfStock });
    quantity.setAttribute("aria-label", `Quantity of ${product.name}`);
    const details = makeButton("Details", "btn-action btn-secondary", () => handleViewProductDetails(product.productID));
    const add = makeButton("Add", "btn-action", () => handleAddToCart(product.productID, quantity.value));
    add.disabled = outOfStock;
    return [details, quantity, add];
}
async function handleViewProductDetails(productID) {
    try {
        const product = await OLMSApi.products.get(productID);
        const list = document.createElement("dl");
        list.className = "details-list";
        [["Product ID", product.productID], ["Name", product.name], ["Price", formatMoney(product.price)],
            ["Stock Quantity", product.stockQuantity], ["Availability", product.stockQuantity > 0 ? "In stock" : "Out of stock"]]
            .forEach(([term, value]) => {
                list.append(Object.assign(document.createElement("dt"), { textContent: term }));
                list.append(Object.assign(document.createElement("dd"), { textContent: String(value) }));
            });
        byId("productDetailsDisplay").replaceChildren(list);
    } catch (error) { showError("browseFeedback", error); }
}
function handleAddToCart(productID, rawQuantity) {
    try {
        const product = app.products.find(item => item.productID === productID);
        if (!product) throw new Error("This product is no longer available. Refresh the catalogue.");
        const quantity = Number(rawQuantity);
        if (!Number.isSafeInteger(quantity) || quantity < 1) throw new Error("Quantity must be a whole number of at least 1.");
        const existing = app.cart.find(line => line.productID === productID);
        const requested = quantity + (existing?.quantity || 0);
        if (requested > product.stockQuantity) throw new Error(`Only ${product.stockQuantity} unit(s) of ${product.name} are available.`);
        if (existing) existing.quantity = requested;
        else app.cart.push({ productID, quantity });
        showMessage("cartFeedback", "success", `Added ${quantity} × ${product.name} to cart.`);
        renderCart();
    } catch (error) { showError("cartFeedback", error); }
}
function handleRemoveFromCart(productID) {
    app.cart = app.cart.filter(line => line.productID !== productID);
    clearMessage("cartFeedback");
    renderCart();
}
function renderCart() {
    let totalCents = 0;
    const rows = app.cart.map(line => {
        const product = app.products.find(item => item.productID === line.productID);
        const subtotal = product ? Math.round(product.price * 100) * line.quantity : 0;
        totalCents += subtotal;
        return [product?.name || `${line.productID} (no longer available)`, line.quantity,
            formatMoney(subtotal / 100), makeButton("Remove", "btn-action btn-danger", () => handleRemoveFromCart(line.productID))];
    });
    renderTable(byId("cartDisplay"), ["Product", "Qty", "Subtotal", ""], rows, "Your cart is empty.");
    byId("cartTotal").textContent = `Total: ${formatMoney(totalCents / 100)}`;
    byId("placeOrderBtn").disabled = app.cart.length === 0;
}
async function handlePlaceOrder() {
    try {
        requireSession("customer");
        if (!app.cart.length) throw new Error("Your cart is empty. Add a product before placing an order.");
        const order = await OLMSApi.orders.place(app.cart.map(line => ({ ...line })));
        app.cart = [];
        showMessage("cartFeedback", "success", `Order ${order.orderID} placed. Total: ${formatMoney(order.totalAmount)}. Status: ${order.status}.`);
    } catch (error) { showError("cartFeedback", error); }
    renderCart();
    await renderCatalogue();
    await renderCustomerOrders();
}
async function renderCustomerOrders() {
    try {
        const orders = (await OLMSApi.orders.list()).slice().reverse();
        const rows = orders.map(order => [order.orderID, formatDate(order.createdAt), describeItems(order),
            formatMoney(order.totalAmount), buildStatusCell(order.status)]);
        renderTable(byId("customerOrdersDisplay"), ["Order ID", "Placed", "Products", "Total", "Status and next step"], rows,
            "You have not placed any orders yet.");
    } catch (error) { showMessage("cartFeedback", "error", error.message); }
}

// ----- Staff product management -------------------------------------------
function readProductForm(prefix) {
    const priceText = byId(`${prefix}_price`).value.trim();
    const stockText = byId(`${prefix}_stockQuantity`).value.trim();
    return {
        productID: byId(`${prefix}_productID`).value,
        name: byId(`${prefix}_name`).value,
        price: priceText === "" ? NaN : Number(priceText),
        stockQuantity: stockText === "" ? NaN : Number(stockText)
    };
}
async function initStaffView() {
    closeEditWorkspace();
    byId("createProductForm").reset();
    byId("search_query").value = "";
    lastStaffSearch = "";
    byId("searchResultsDisplay").replaceChildren();
    clearMessage("createFeedback");
    clearMessage("searchFeedback");
    await renderInventoryTable();
    renderStatusGuide("staffStatusGuide", "Orders move forward one step at a time. Staff choose the next status below; the rules are the same for every order.");
    initOrderManagement();
}
async function refreshProductViews() {
    await renderInventoryTable();
    if (lastStaffSearch) await renderSearchResults(lastStaffSearch);
}
async function renderInventoryTable() {
    try {
        app.products = await OLMSApi.products.list();
        const rows = app.products.map(product => [product.productID, product.name, formatMoney(product.price), product.stockQuantity,
            [makeButton("Edit", "btn-action", () => openEditWorkspace(product.productID), "Load this product into the edit form"),
                makeButton("Delete", "btn-action btn-danger", () => confirmDirectDelete(product.productID), "Delete this product")]]);
        renderTable(byId("inventoryDisplay"), ["Product ID", "Product Name", "Price", "Stock Quantity", "Operations"], rows,
            "No products found in system.");
    } catch (error) { showMessage("createFeedback", "error", error.message); }
}
async function handleCreateProduct(event) {
    event.preventDefault();
    try {
        const product = await OLMSApi.products.create(readProductForm("create"));
        showMessage("createFeedback", "success", `Product [${product.productID}] "${product.name}" created successfully.`);
        byId("createProductForm").reset();
        await refreshProductViews();
    } catch (error) { showError("createFeedback", error); }
}
async function handleSearchProduct(event) {
    event.preventDefault();
    try {
        lastStaffSearch = Validator.searchQuery(byId("search_query").value, { required: true });
        await renderSearchResults(lastStaffSearch);
    } catch (error) {
        lastStaffSearch = "";
        byId("searchResultsDisplay").replaceChildren();
        showError("searchFeedback", error);
    }
}
async function renderSearchResults(query) {
    try {
        const matches = await OLMSApi.products.list(query);
        if (!matches.length) {
            byId("searchResultsDisplay").replaceChildren();
            showMessage("searchFeedback", "error", `Not found: No product matching "${query}".`);
            return;
        }
        showMessage("searchFeedback", "info", `Search successful: Found ${matches.length} matching product(s).`);
        const rows = matches.map(product => [product.productID, product.name, formatMoney(product.price), product.stockQuantity,
            makeButton("Edit / Delete", "btn-action", () => openEditWorkspace(product.productID), "Open this product in the edit / delete panel")]);
        renderTable(byId("searchResultsDisplay"), ["ID", "Name", "Price", "Stock", "Action"], rows, "");
    } catch (error) { showError("searchFeedback", error); }
}
async function openEditWorkspace(productID) {
    try {
        const product = await OLMSApi.products.get(productID);
        byId("edit_productID").value = product.productID;
        byId("edit_name").value = product.name;
        byId("edit_price").value = product.price.toFixed(2);
        byId("edit_stockQuantity").value = product.stockQuantity;
        byId("editTitle").textContent = `3 & 4. Edit / Delete Product ${product.productID}`;
        showMessage("editFeedback", "info", `Loaded product ${product.productID} for editing.`);
        byId("editDeleteSection").classList.remove("hidden");
        byId("editDeleteSection").scrollIntoView({ behavior: "smooth" });
        return true;
    } catch (error) { showError("searchFeedback", error); return false; }
}
async function handleSaveEdit(event) {
    event.preventDefault();
    try {
        const form = readProductForm("edit");
        const product = await OLMSApi.products.update(form.productID, form);
        byId("edit_price").value = product.price.toFixed(2);
        showMessage("editFeedback", "success", `Product ${product.productID} updated successfully.`);
        await refreshProductViews();
    } catch (error) { showError("editFeedback", error); }
}
async function handleDeletePrompt() {
    const productID = byId("edit_productID").value;
    try {
        const product = await OLMSApi.products.get(productID);
        const confirmed = confirm(`Confirm Deletion?\n\nProduct ID: ${product.productID}\nName: ${product.name}\nPrice: ${formatMoney(product.price)}\nStock: ${product.stockQuantity}\n\nAre you sure you want to delete this record?`);
        if (!confirmed) return false;
        await OLMSApi.products.delete(productID);
        closeEditWorkspace();
        await refreshProductViews();
        alert(`Product ${product.productID} has been permanently deleted.`);
        return true;
    } catch (error) { showError("editFeedback", error); return false; }
}
async function confirmDirectDelete(productID) {
    if (await openEditWorkspace(productID)) {
        if (!await handleDeletePrompt()) closeEditWorkspace();
    }
}
function closeEditWorkspace() {
    byId("editDeleteSection").classList.add("hidden");
    byId("editForm").reset();
    clearMessage("editFeedback");
}

// ----- Staff order management ---------------------------------------------
function initOrderManagement() {
    byId("order_status_filter").value = "";
    clearMessage("orderFeedback");
    renderOrderManagement();
}
async function renderOrderManagement() {
    try {
        let orders = await OLMSApi.orders.list();
        const filter = byId("order_status_filter").value;
        if (filter) orders = orders.filter(order => order.status === filter);
        orders.reverse();
        const rows = orders.map(order => [order.orderID, order.customerID, describeItems(order), formatMoney(order.totalAmount),
            buildStatusCell(order.status), buildStatusControls(order)]);
        renderTable(byId("orderManagementDisplay"), ["Order ID", "Customer ID", "Products", "Total", "Status and next step", "Update Status"],
            rows, "No orders found.");
    } catch (error) { showError("orderFeedback", error); }
}
function buildStatusControls(order) {
    const nextStatuses = ORDER_STATUS_FLOW[order.status] || [];
    if (!nextStatuses.length) return makeNoteLine("Final status - no further changes.", "final-label");
    const select = document.createElement("select");
    select.className = "status-select";
    select.setAttribute("aria-label", `New status for ${order.orderID}`);
    nextStatuses.forEach(status => select.add(new Option(ORDER_STATUS_INFO[status].staffAction, status)));
    const button = makeButton("Update Status", "btn-action", () => handleUpdateOrderStatus(order.orderID, select.value),
        "Apply the selected status to this order");
    const row = document.createElement("div");
    row.className = "update-row";
    row.append(select, button);
    return row;
}
async function handleUpdateOrderStatus(orderID, newStatus) {
    try {
        const order = await OLMSApi.orders.updateStatus(orderID, newStatus);
        const note = newStatus === OrderStatus.CANCELLED ? " Stock has been returned to inventory." : "";
        showMessage("orderFeedback", "success", `Order ${order.orderID} is now ${order.status}.${note}`);
        await renderInventoryTable();
    } catch (error) { showError("orderFeedback", error); }
    await renderOrderManagement();
}

// Initialize the API-backed interface.
enterSession();
