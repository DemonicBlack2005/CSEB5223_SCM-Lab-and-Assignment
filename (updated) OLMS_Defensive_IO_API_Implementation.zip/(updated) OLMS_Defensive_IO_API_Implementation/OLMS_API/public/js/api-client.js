/* OLMS REST API client. Include after the page's scripts when migrating UI handlers to API calls. */
(() => {
  'use strict';
  const API_BASE = '/api';
  let accessToken = null;

  async function request(path, options = {}) {
    if (typeof path !== 'string' || !path.startsWith('/')) throw new TypeError('API path must start with /.');
    const headers = new Headers(options.headers || {});
    headers.set('Accept', 'application/json');
    if (options.body !== undefined) headers.set('Content-Type', 'application/json');
    if (accessToken) headers.set('Authorization', `Bearer ${accessToken}`);
    let response;
    try {
      response = await fetch(`${API_BASE}${path}`, { ...options, headers, body: options.body === undefined ? undefined : JSON.stringify(options.body) });
    } catch {
      throw new Error('Cannot reach the OLMS server. Check your connection and try again.');
    }
    let payload;
    try { payload = await response.json(); }
    catch { throw new Error(`Server returned an unreadable response (HTTP ${response.status}).`); }
    if (!response.ok) throw new Error(payload?.error?.message || `Request failed (HTTP ${response.status}).`);
    return payload?.data;
  }

  window.OLMSApi = Object.freeze({
    async login(role, email, password) { const data = await request('/auth/login', {method:'POST',body:{role,email,password}}); accessToken=data.token; return data.user; },
    async register(details) { const data = await request('/auth/register', {method:'POST',body:details}); accessToken=data.token; return data.user; },
    async logout() { try { return await request('/auth/logout',{method:'POST'}); } finally { accessToken=null; } },
    products: { list: q => request(`/products${q ? `?q=${encodeURIComponent(q)}` : ''}`), get: id => request(`/products/${encodeURIComponent(id)}`), create: p => request('/products',{method:'POST',body:p}), update:(id,p)=>request(`/products/${encodeURIComponent(id)}`,{method:'PUT',body:p}), delete:id=>request(`/products/${encodeURIComponent(id)}`,{method:'DELETE'}) },
    orders: { list:()=>request('/orders'), get:id=>request(`/orders/${encodeURIComponent(id)}`), place:items=>request('/orders',{method:'POST',body:{items}}), updateStatus:(id,status)=>request(`/orders/${encodeURIComponent(id)}/status`,{method:'PATCH',body:{status}}) },
    health:()=>request('/health')
  });
})();
