# OLMS — Defensive I/O Programming & REST API

This package extends the supplied Online Local Mart System with a Node.js + Express REST API. It retains the original HTML/CSS/JavaScript project in `public/` and adds an API server in `server.js`.

## 1. Run locally

Requirements: Node.js 20 or later and npm.

```bash
cd OLMS_API
npm install
npm start
```

Open `http://localhost:3000` for the original OLMS interface and `http://localhost:3000/api/health` to check the API.

## 2. Demo accounts

| Role | Email | Password |
|---|---|---|
| Staff | staff@olms.test | staff123 |
| Customer | customer@olms.test | customer123 |

These are development-only demo credentials. Do not deploy them publicly.

## 3. REST API endpoints

All successful responses use `{ "data": ... }`; errors use `{ "error": { "code": ..., "message": ... } }`.

| Method | Endpoint | Access | Purpose |
|---|---|---|---|
| GET | `/api/health` | Public | Health check |
| POST | `/api/auth/register` | Public | Register customer |
| POST | `/api/auth/login` | Public | Login as customer or staff |
| POST | `/api/auth/logout` | Authenticated | End session |
| GET | `/api/products?q=milk` | Public | List/search products |
| GET | `/api/products/:id` | Public | Read product |
| POST | `/api/products` | Staff | Create product |
| PUT | `/api/products/:id` | Staff | Update product |
| DELETE | `/api/products/:id` | Staff | Delete product |
| POST | `/api/orders` | Customer | Place order |
| GET | `/api/orders` | Authenticated | List own orders (staff sees all) |
| GET | `/api/orders/:id` | Owner or staff | Read order |
| PATCH | `/api/orders/:id/status` | Staff | Advance order status |

Authenticated calls must include `Authorization: Bearer <token>` returned by login/register.

## 4. Defensive I/O programming implemented

- JSON request parsing with a 32 KB body limit and malformed-JSON handling.
- Request-body type checks; rejects arrays, null and non-object payloads.
- Server-side validation independent of browser form validation: bounded strings, control-character rejection, email and phone formats, password length, numeric type/range checks, integer stock/quantity and two-decimal prices.
- Product ID normalisation and format validation; duplicate IDs and duplicate customer emails return conflict errors.
- Search query length limit; path IDs are normalised before lookup.
- Authentication and role-based access control; customers cannot read other customers' orders or perform staff operations.
- Order lines are fully validated and stock availability checked before inventory is changed (all-or-nothing placement).
- Order lifecycle transitions are allow-listed. Cancellation is only allowed from Pending or Processing and restores stock once.
- Safe JSON response objects omit passwords; frontend API client handles network failures, unreadable responses and API errors.
- Security headers, request rate limiting, disabled Express signature header and generic internal-server errors.

## 5. Example API calls

Health:
```bash
curl http://localhost:3000/api/health
```

Staff login:
```bash
curl -X POST http://localhost:3000/api/auth/login \
  -H "Content-Type: application/json" \
  -d '{"role":"staff","email":"staff@olms.test","password":"staff123"}'
```

Create product (replace TOKEN with the returned token):
```bash
curl -X POST http://localhost:3000/api/products \
  -H "Content-Type: application/json" -H "Authorization: Bearer TOKEN" \
  -d '{"productID":"P005","name":"Orange Juice 1L","price":4.5,"stockQuantity":20}'
```

Place order (customer token):
```bash
curl -X POST http://localhost:3000/api/orders \
  -H "Content-Type: application/json" -H "Authorization: Bearer CUSTOMER_TOKEN" \
  -d '{"items":[{"productID":"P001","quantity":2}]}'
```

## 6. Frontend integration

`public/js/api-client.js` exposes `window.OLMSApi` methods for authentication, products and orders. It is intentionally provided as a separate client adapter so existing coursework UI handlers can be migrated incrementally without replacing the original class/repository design in one risky change. To use it, add this script before the existing UI controller script and update event handlers to `await OLMSApi...` calls. The original supplied UI still uses its existing in-browser in-memory repositories; the REST endpoints are independently runnable and testable.

## 7. Important limitations / production hardening

The API currently uses in-memory data and demo plaintext passwords to stay compatible with the supplied demo account model. Data resets when the server restarts. For real deployment, use a database, bcrypt/Argon2 password hashing, persistent sessions or signed short-lived tokens, HTTPS, environment-managed secrets, CSRF protection if cookie auth is introduced, audit logging and automated integration tests. Do not expose this demo API to the public internet.
