'use strict';

const express = require('express');
const helmet = require('helmet');
const rateLimit = require('express-rate-limit');
const crypto = require('node:crypto');
const path = require('node:path');

const app = express();
const PORT = Number(process.env.PORT) || 3000;
const MAX_BODY = '32kb';
app.disable('x-powered-by');
app.use(helmet({ contentSecurityPolicy: false }));
app.use(express.json({ limit: MAX_BODY, strict: true }));
app.use(express.urlencoded({ extended: false, limit: MAX_BODY }));
app.use('/api/', rateLimit({ windowMs: 15 * 60 * 1000, limit: 300, standardHeaders: 'draft-7', legacyHeaders: false }));
app.use(express.static(path.join(__dirname, 'public')));

const STATUS = Object.freeze({ PENDING:'Pending', PROCESSING:'Processing', SHIPPED:'Shipped', DELIVERED:'Delivered', CANCELLED:'Cancelled' });
const NEXT = Object.freeze({ Pending:['Processing','Cancelled'], Processing:['Shipped','Cancelled'], Shipped:['Delivered'], Delivered:[], Cancelled:[] });
const db = {
  products: [
    { productID:'P001', name:'Fresh Farm Milk 1L', price:3.50, stockQuantity:25 },
    { productID:'P002', name:'Whole Wheat Bread', price:2.80, stockQuantity:18 },
    { productID:'P003', name:'Organic Brown Eggs (10s)', price:4.20, stockQuantity:30 },
    { productID:'P004', name:'Green Gala Apples (1kg)', price:5.90, stockQuantity:12 }
  ],
  customers: [{ customerID:'C001', name:'Demo Customer', email:'customer@olms.test', phone:'012-3456789', password:'customer123' }],
  staff: [{ staffID:'S001', name:'Mart Manager', email:'staff@olms.test', role:'Manager', password:'staff123' }],
  orders: [], sessions: new Map(), nextCustomer:2, nextOrder:1
};

class HttpError extends Error { constructor(status, message, code='REQUEST_ERROR') { super(message); this.status=status; this.code=code; } }
const fail = (status, message, code) => { throw new HttpError(status, message, code); };
const isObject = value => value !== null && typeof value === 'object' && !Array.isArray(value);
function bodyObject(req) { if (!isObject(req.body)) fail(400, 'Request body must be a JSON object.', 'INVALID_BODY'); return req.body; }
function text(value, field, min=1, max=100) {
  if (typeof value !== 'string') fail(400, `${field} must be text.`, 'INVALID_FIELD');
  const v=value.trim(); if (v.length<min || v.length>max || /[\u0000-\u001f\u007f]/.test(v)) fail(400, `${field} must contain ${min}-${max} valid characters.`, 'INVALID_FIELD');
  return v;
}
function email(value) { const v=text(value,'Email',3,254).toLowerCase(); if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(v)) fail(400,'Enter a valid email address.','INVALID_EMAIL'); return v; }
function password(value) { if (typeof value!=='string' || value.length<8 || value.length>128) fail(400,'Password must be 8-128 characters.','INVALID_PASSWORD'); return value; }
function number(value, field, min, integer=false) { if (typeof value!=='number' || !Number.isFinite(value) || value<min || (integer && !Number.isInteger(value))) fail(400,`${field} must be a valid ${integer?'whole number':'number'} greater than or equal to ${min}.`,'INVALID_NUMBER'); return value; }
function productInput(b) {
  const productID=text(b.productID,'Product ID',4,12).toUpperCase();
  if (!/^P\d{3,}$/.test(productID)) fail(400,'Product ID must start with P followed by at least three digits.','INVALID_PRODUCT_ID');
  const name=text(b.name,'Product name',2,100);
  const price=number(b.price,'Price',0); if (Math.round(price*100)!==price*100) fail(400,'Price must have no more than two decimal places.','INVALID_PRICE');
  const stockQuantity=number(b.stockQuantity,'Stock quantity',0,true);
  return { productID,name,price,stockQuantity };
}
function publicUser(user, role) { const {password:_,...safe}=user; return { ...safe, role }; }
function auth(req,res,next) {
  const token=(req.get('authorization')||'').replace(/^Bearer\s+/i,'');
  const session=db.sessions.get(token);
  if (!session) return res.status(401).json({error:{code:'UNAUTHENTICATED',message:'Please log in to continue.'}});
  req.user=session; req.token=token; next();
}
function staffOnly(req,res,next) { if(req.user.role!=='staff') return res.status(403).json({error:{code:'FORBIDDEN',message:'Staff access is required.'}}); next(); }
function customerOnly(req,res,next) { if(req.user.role!=='customer') return res.status(403).json({error:{code:'FORBIDDEN',message:'Customer access is required.'}}); next(); }
function safeProduct(p) { return {productID:p.productID,name:p.name,price:p.price,stockQuantity:p.stockQuantity}; }
function safeOrder(o) { return {orderID:o.orderID,customerID:o.customerID,items:o.items.map(x=>({...x})),totalAmount:o.totalAmount,status:o.status,createdAt:o.createdAt}; }

app.get('/api/health',(req,res)=>res.json({status:'ok',service:'OLMS API',version:'1.0.0'}));
app.post('/api/auth/register',(req,res)=>{
  const b=bodyObject(req), name=text(b.name,'Name',2,80), mail=email(b.email), phone=text(b.phone,'Phone',7,20), pass=password(b.password);
  if(!/^[+\d()\-\s]{7,20}$/.test(phone)) fail(400,'Enter a valid phone number.','INVALID_PHONE');
  if(db.customers.some(c=>c.email===mail)) fail(409,'An account with this email already exists.','EMAIL_EXISTS');
  const user={customerID:`C${String(db.nextCustomer++).padStart(3,'0')}`,name,email:mail,phone,password:pass}; db.customers.push(user);
  const token=crypto.randomBytes(32).toString('hex'); db.sessions.set(token,{role:'customer',id:user.customerID});
  res.status(201).json({data:{user:publicUser(user,'customer'),token}});
});
app.post('/api/auth/login',(req,res)=>{
  const b=bodyObject(req), role=text(b.role,'Role',1,10).toLowerCase(); if(!['customer','staff'].includes(role)) fail(400,'Choose Customer or Staff.','INVALID_ROLE');
  const mail=email(b.email); if(typeof b.password!=='string'||!b.password) fail(400,'Password is required.','INVALID_PASSWORD');
  const user=(role==='staff'?db.staff:db.customers).find(u=>u.email===mail && u.password===b.password);
  if(!user) fail(401,'Invalid email or password.','INVALID_CREDENTIALS');
  const token=crypto.randomBytes(32).toString('hex'); db.sessions.set(token,{role,id:user.customerID||user.staffID});
  res.json({data:{user:publicUser(user,role),token}});
});
app.post('/api/auth/logout',auth,(req,res)=>{db.sessions.delete(req.token);res.json({data:{message:'Logged out successfully.'}});});
app.get('/api/products',(req,res)=>{
  let list=db.products; const q=String(req.query.q||'').trim().toLowerCase();
  if(q.length>100) fail(400,'Search query is too long.','INVALID_QUERY');
  if(q) list=list.filter(p=>p.productID.toLowerCase().includes(q)||p.name.toLowerCase().includes(q));
  res.json({data:list.map(safeProduct)});
});
app.get('/api/products/:id',(req,res)=>{const p=db.products.find(x=>x.productID===String(req.params.id).toUpperCase());if(!p)fail(404,'Product not found.','NOT_FOUND');res.json({data:safeProduct(p)});});
app.post('/api/products',auth,staffOnly,(req,res)=>{
  const p=productInput(bodyObject(req)); if(db.products.some(x=>x.productID===p.productID)) fail(409,'Product ID already exists.','DUPLICATE_PRODUCT');
  db.products.push(p); res.status(201).json({data:safeProduct(p)});
});
app.put('/api/products/:id',auth,staffOnly,(req,res)=>{
  const id=String(req.params.id).toUpperCase(), old=db.products.find(x=>x.productID===id); if(!old) fail(404,'Product not found.','NOT_FOUND');
  const b=bodyObject(req), candidate=productInput({...b,productID:id}); Object.assign(old,candidate); res.json({data:safeProduct(old)});
});
app.delete('/api/products/:id',auth,staffOnly,(req,res)=>{const i=db.products.findIndex(x=>x.productID===String(req.params.id).toUpperCase());if(i<0)fail(404,'Product not found.','NOT_FOUND');db.products.splice(i,1);res.json({data:{message:'Product deleted.'}});});
app.post('/api/orders',auth,customerOnly,(req,res)=>{
  const b=bodyObject(req); if(!Array.isArray(b.items)||b.items.length<1||b.items.length>50) fail(400,'Order must contain between 1 and 50 item lines.','INVALID_ORDER');
  const aggregated=new Map();
  for(const line of b.items){if(!isObject(line))fail(400,'Each order item must be an object.','INVALID_ORDER_LINE');const id=text(line.productID,'Product ID',4,12).toUpperCase();const qty=number(line.quantity,'Quantity',1,true);aggregated.set(id,(aggregated.get(id)||0)+qty);}
  const resolved=[...aggregated].map(([id,quantity])=>{const p=db.products.find(x=>x.productID===id);if(!p)fail(404,`Product ${id} was not found.`,'PRODUCT_NOT_FOUND');if(p.stockQuantity<quantity)fail(409,`Only ${p.stockQuantity} unit(s) of ${p.name} remain.`,'INSUFFICIENT_STOCK');return {product:p,quantity};});
  const items=resolved.map(({product,quantity})=>({productID:product.productID,name:product.name,unitPrice:product.price,quantity,subtotal:Number((product.price*quantity).toFixed(2))}));
  const order={orderID:`ORD${String(db.nextOrder++).padStart(4,'0')}`,customerID:req.user.id,items,totalAmount:Number(items.reduce((s,x)=>s+x.subtotal,0).toFixed(2)),status:STATUS.PENDING,createdAt:new Date().toISOString()};
  resolved.forEach(x=>x.product.stockQuantity-=x.quantity); db.orders.push(order); res.status(201).json({data:safeOrder(order)});
});
app.get('/api/orders',auth,(req,res)=>{const orders=req.user.role==='staff'?db.orders:db.orders.filter(o=>o.customerID===req.user.id);res.json({data:orders.map(safeOrder)});});
app.get('/api/orders/:id',auth,(req,res)=>{const o=db.orders.find(x=>x.orderID===String(req.params.id).toUpperCase());if(!o)fail(404,'Order not found.','NOT_FOUND');if(req.user.role!=='staff'&&o.customerID!==req.user.id)fail(403,'You cannot view another customer\'s order.','FORBIDDEN');res.json({data:safeOrder(o)});});
app.patch('/api/orders/:id/status',auth,staffOnly,(req,res)=>{
  const o=db.orders.find(x=>x.orderID===String(req.params.id).toUpperCase());if(!o)fail(404,'Order not found.','NOT_FOUND');const b=bodyObject(req), next=text(b.status,'Status',1,20);
  if(!Object.values(STATUS).includes(next))fail(400,'Unknown order status.','INVALID_STATUS');if(!NEXT[o.status].includes(next))fail(409,`Cannot change order from ${o.status} to ${next}.`,'INVALID_TRANSITION');
  o.status=next;if(next===STATUS.CANCELLED)o.items.forEach(item=>{const p=db.products.find(x=>x.productID===item.productID);if(p)p.stockQuantity+=item.quantity;});res.json({data:safeOrder(o)});
});

app.use('/api',(req,res)=>res.status(404).json({error:{code:'ROUTE_NOT_FOUND',message:'API endpoint not found.'}}));
app.use((err,req,res,next)=>{
  if(err instanceof SyntaxError && 'body' in err) return res.status(400).json({error:{code:'MALFORMED_JSON',message:'Request body contains invalid JSON.'}});
  const status=err.status||500; const message=status===500?'An unexpected server error occurred.':err.message;
  if(status===500) console.error(err);
  res.status(status).json({error:{code:err.code||'INTERNAL_ERROR',message}});
});
if (require.main === module) app.listen(PORT,()=>console.log(`OLMS API running at http://localhost:${PORT}`));
module.exports={app,db};
