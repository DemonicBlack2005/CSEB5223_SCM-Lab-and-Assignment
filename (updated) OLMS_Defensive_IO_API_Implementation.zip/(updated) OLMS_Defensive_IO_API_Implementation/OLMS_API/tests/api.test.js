'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const { app, db } = require('../server');
let server, base;
async function call(path, {method='GET',token,body}={}) {
  const headers={Accept:'application/json'}; if(body!==undefined) headers['Content-Type']='application/json'; if(token) headers.Authorization=`Bearer ${token}`;
  const response=await fetch(`${base}${path}`,{method,headers,body:body===undefined?undefined:JSON.stringify(body)});
  return {status:response.status,body:await response.json()};
}
test.before(async()=>{server=app.listen(0);await new Promise(resolve=>server.once('listening',resolve));base=`http://127.0.0.1:${server.address().port}`;});
test.after(async()=>{await new Promise((resolve,reject)=>server.close(err=>err?reject(err):resolve()));});
test('health endpoint responds',async()=>{const r=await call('/api/health');assert.equal(r.status,200);assert.equal(r.body.status,'ok');});
test('malformed JSON is rejected',async()=>{const r=await fetch(`${base}/api/auth/login`,{method:'POST',headers:{'Content-Type':'application/json'},body:'{bad'});assert.equal(r.status,400);assert.equal((await r.json()).error.code,'MALFORMED_JSON');});
test('staff can create product; invalid price is rejected',async()=>{
  const login=await call('/api/auth/login',{method:'POST',body:{role:'staff',email:'staff@olms.test',password:'staff123'}});assert.equal(login.status,200);const token=login.body.data.token;
  const invalid=await call('/api/products',{method:'POST',token,body:{productID:'P005',name:'Orange Juice',price:1.999,stockQuantity:4}});assert.equal(invalid.status,400);
  const created=await call('/api/products',{method:'POST',token,body:{productID:'P005',name:'Orange Juice',price:1.99,stockQuantity:4}});assert.equal(created.status,201);assert.equal(created.body.data.productID,'P005');
});
test('customer order placement validates stock before reducing inventory',async()=>{
  const login=await call('/api/auth/login',{method:'POST',body:{role:'customer',email:'customer@olms.test',password:'customer123'}});const token=login.body.data.token;
  const before=db.products.find(p=>p.productID==='P001').stockQuantity;
  const bad=await call('/api/orders',{method:'POST',token,body:{items:[{productID:'P001',quantity:999}]}});assert.equal(bad.status,409);assert.equal(db.products.find(p=>p.productID==='P001').stockQuantity,before);
  const placed=await call('/api/orders',{method:'POST',token,body:{items:[{productID:'P001',quantity:2}]}});assert.equal(placed.status,201);assert.equal(db.products.find(p=>p.productID==='P001').stockQuantity,before-2);
});
test('customer cannot access staff product creation',async()=>{
  const login=await call('/api/auth/login',{method:'POST',body:{role:'customer',email:'customer@olms.test',password:'customer123'}});
  const r=await call('/api/products',{method:'POST',token:login.body.data.token,body:{productID:'P006',name:'Test Product',price:2,stockQuantity:1}});assert.equal(r.status,403);
});
